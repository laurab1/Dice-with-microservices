[![Build Status](https://travis-ci.org/laurab1/Dice-with-microservices.svg?branch=develop&service=github)](https://travis-ci.org/laurab1/Dice-with-microservices)  [![Coverage Status](https://coveralls.io/repos/github/laurab1/Dice-with-microservices/badge.svg?branch=develop)](https://coveralls.io/github/laurab1/Dice-with-microservices?branch=develop)

# Dice-with-microservices
